# Nuke caravan
Nuke Caravan sandbox game in pure JavaScript / HTML / Css
***
Игра про  караван на чистом JavaScript / HTML / Css. 
+ [Описание на Хабре](https://habrahabr.ru/post/336724/).
+ [Живое демо](http://skachat-besplatno.ru/gamelab/zoolander/).
***
Последние исправления

21.09.2017 - размер лога теперь ограничен константой в GameConstants. Причина: тормоза и OutOfMemoryException у манчкинов, играющих слишком долго при бесконечном размере лога. 

21.09.2017 - исправлен баг бесконечного цикла при забитии браминов, когда заканчивается еда, в Core Plugin
